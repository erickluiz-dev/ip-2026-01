package main

import (
	"database/sql"
	f "fmt"
	"net/http"
	_ "github.com/lib/pq"
)

var db *sql.DB

func main() {

	var err error

	conectarStr := "user=postgres password=esufg123 dbname=clinica_ip host=localhost port=5432 sslmode=disable"

	db, err = sql.Open("postgres", conectarStr)
	if err != nil{
		panic("Erro ao configurar o banco de dados: " + err.Error())
	}

	err = db.Ping()
	if err != nil{
		panic("Não foi possível conectar ao banco de dados: " + err.Error())
	}
	
	f.Println("✅ Conectado ao banco de dados PostgreSQL com sucesso!")

	http.HandleFunc("/FormAccount", FormAccountHandler)
	http.HandleFunc("/FormMedical", FormMedicalHandler)
	http.HandleFunc("/", IndexHandler)

	porta := ":5500"
	f.Println("🚀 Servidor rodando na porta", porta)

	err = http.ListenAndServe(porta, nil)
	if err != nil {
		panic("Erro ao iniciar o servidor: " + err.Error())
	}
}	